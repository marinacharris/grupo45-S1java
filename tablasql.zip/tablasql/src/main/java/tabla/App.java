package tabla;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;
import java.sql.*;

public class App extends JFrame {

    public App(){

        String jdbcUrl = "jdbc:sqlite:hr.db";
        try{
            Connection conexion = DriverManager.getConnection(jdbcUrl); //conectando JDBC a sqlite
            String sql = "select * from departments";
            Statement stm = conexion.createStatement(); 
            ResultSet rs = stm.executeQuery(sql);

            DefaultTableModel modelo = new DefaultTableModel();
            JTable tabla = new JTable(modelo);
            modelo.addColumn("Id");
            modelo.addColumn("Nombre");
            modelo.addColumn("Ubicación");
            

            while(rs.next()){
               Object[] fila = new Object[3];
               for (int i = 0; i < fila.length; i++) {
                    fila[i]=rs.getObject(i+1);
               }
               modelo.addRow(fila);
            
            }
            rs.close();
            stm.close();
            conexion.close();
            tabla.setPreferredScrollableViewportSize(new Dimension(250,100));
            add(tabla);
            JScrollPane scrollPane = new JScrollPane(tabla); 
            add(scrollPane);
        }
        catch(Exception e){
            System.out.println("Error!");
            System.out.println(e.getMessage());
        }
        


    }


    public static void main(String[] args) throws Exception {
        App ventana = new App();    
        ventana.pack();
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}

