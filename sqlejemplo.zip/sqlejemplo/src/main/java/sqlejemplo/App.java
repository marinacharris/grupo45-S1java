package sqlejemplo;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        //SELECT
        String jdbcUrl = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        try{
            Connection conexion = DriverManager.getConnection(jdbcUrl); //conectando JDBC a sqlite
            String sql = "select * from employees e where salary > 10000";
            Statement stm = conexion.createStatement(); 
            ResultSet rs = stm.executeQuery(sql);
            while(rs.next()){
                Integer id = rs.getInt("employee_id");
                String nombre = rs.getString("first_name");
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("salary");
                System.out.println(id + "\t" + nombre + "\t" + apellido + "\t" + salario);
            }
            rs.close();
            stm.close();
            conexion.close();
        }
        catch(Exception e){
            System.out.println("Error!");
            System.out.println(e.getMessage());
        }
        System.out.println();
        consultaEmpleado(200);
        //actualizarDep();
        borrarRegion(5);
        actualizarDep(18);
    }


    // select con preparedStatement 
    public static void consultaEmpleado(int employee_id) throws SQLException{
        String jdbcUrl = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        String sql = "select * from employees where employee_id = ?";
        try{
            Connection conexion = DriverManager.getConnection(jdbcUrl);
            PreparedStatement stmp = conexion.prepareStatement(sql);
            stmp.setInt(1,employee_id);
            ResultSet rs = stmp.executeQuery();
            while(rs.next()){
                Integer id = rs.getInt("employee_id");
                String nombre = rs.getString("first_name");
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("salary");
                System.out.println(id + "\t" + nombre + "\t" + apellido + "\t" + salario);
            }
            rs.close();
            stmp.close();
            conexion.close();
        }
        catch(Exception e){
            System.out.println("Error!");
            System.out.println(e.getMessage());
        }
            
    }

    //Insert into
    public static void actualizarDep(){
        try{
            String url = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
            Connection conexion = DriverManager.getConnection(url);
            String sql = "insert into departments (department_name, location_id) values ('I+D',1500)";
            Statement stm = conexion.createStatement();
            int rows = stm.executeUpdate(sql);
            if (rows>0){
                System.out.println("Registro creado con exito");
            }
            stm.close();
            conexion.close();
        }
        catch(Exception e){
            System.out.println(e.getMessage());

        }
    }

    //Borrar 
    public static void borrarRegion(int region_id) throws SQLException{
        String url = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        String sql = "delete from regions where region_id = " + region_id;

        try(
            Connection conexion = DriverManager.getConnection(url);
            Statement stm = conexion.createStatement(); //los recursos abiertos entre los paréntesis se cierran automaticamente al finalizar el try
        ){
            int rows = stm.executeUpdate(sql);
            if (rows > 0 ){
                System.out.println("Registro borrado");
            }
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }

    }

    // Actualizar
    public static void actualizarDep(int dep_id) throws SQLException{
        String url = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        String sql = "update departments set department_name = 'Mantenimiento' where department_id = 18";
        try(
            Connection conexion = DriverManager.getConnection(url);
            Statement stm = conexion.createStatement();
        ){
            int rows = stm.executeUpdate(sql);
            if (rows >0){
                System.out.println("Registro actualizado");
            }

        }
    }
    
}
