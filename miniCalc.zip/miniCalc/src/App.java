import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.Font;
import java.awt.event.*;


public class App extends JFrame implements ActionListener, ChangeListener{
    private JTextField txtField1, txtField2;
    private JButton btnCalcular;
    private JLabel lblResultado;
    private JRadioButton radioSuma, radioResta, radioMul, radioDiv;
    private ButtonGroup btnGrupo;

    public App(){
        setLayout(null);
        txtField1 = new JTextField();
        txtField1.setBounds(10, 10, 100, 25);
        getContentPane().add(txtField1);
        txtField2 = new JTextField();
        txtField2.setBounds(10, 50, 100, 25);
        add(txtField2);
        btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(10,90,100,30);    
        add(btnCalcular);
        btnCalcular.addActionListener(this);
        lblResultado = new JLabel("---");
        lblResultado.setBounds(160,10,50,30);
        lblResultado.setFont(new Font("Arial", Font.BOLD,15));
        add(lblResultado);
        btnGrupo = new ButtonGroup();
        radioSuma = new JRadioButton("+");
        radioSuma.setBounds(140,50,50,20);
        radioSuma.addChangeListener(this);
        add(radioSuma);
        btnGrupo.add(radioSuma);
        radioResta = new JRadioButton("-");
        radioResta.setBounds(140, 70, 50,20);
        radioResta.addChangeListener(this);
        add(radioResta);
        btnGrupo.add(radioResta);
        radioMul = new JRadioButton("*");
        radioMul.setBounds(140, 90, 50, 20);
        add(radioMul);
        btnGrupo.add(radioMul);
        radioDiv = new JRadioButton("/");
        radioDiv.setBounds(140,110,50,20);
        add(radioDiv);
        btnGrupo.add(radioDiv);






    }


    public static void main(String[] args) throws Exception {
        App formulario = new App();
        formulario.setBounds(100,100,250, 180);
        formulario.setVisible(true);
        formulario.setTitle("Calculadora");
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==btnCalcular){
            Double resultado = 0.0;
            Double x1 = Double.parseDouble(txtField1.getText());
            Double x2 = Double.parseDouble(txtField2.getText());
            if (radioSuma.isSelected()){
                resultado = x1 + x2;
            }
            if (radioResta.isSelected()){
                resultado = x1 - x2;
            }
            if (radioMul.isSelected()){
                resultado = x1 * x2;
            }
            if (radioDiv.isSelected()){
                resultado = x1 / x2;
            }
          
            lblResultado.setText(String.valueOf(resultado));
        }
        
        
    }


    @Override
    public void stateChanged(ChangeEvent e) {
        /* 
        Double x1 = Double.parseDouble(txtField1.getText());
        Double x2 = Double.parseDouble(txtField2.getText());
        if (radioSuma.isSelected()){
            
            Double resultado = x1 + x2;
            lblResultado.setText(String.valueOf(resultado));
        }
        */
        
    }
}
