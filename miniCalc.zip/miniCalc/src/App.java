import javax.swing.*;
import java.awt.event.*;
import java.nio.channels.ByteChannel;

public class App extends JFrame implements ActionListener{
    private JTextField txtField1, txtField2;
    private JButton btnCalcular;
    private JLabel lblResultado;

    public App(){
        setLayout(null);
        txtField1 = new JTextField();
        txtField1.setBounds(10, 10, 100, 30);
        add(txtField1);
        txtField2 = new JTextField();
        txtField2.setBounds(10, 50, 100, 30);
        add(txtField2);
        btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(10,90,100,30);    
        add(btnCalcular);
        btnCalcular.addActionListener(this);
        lblResultado = new JLabel("---");
        lblResultado.setBounds(160,50,50,30);
        add(lblResultado);
    }


    public static void main(String[] args) throws Exception {
        App formulario = new App();
        formulario.setBounds(100,100,250, 180);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==btnCalcular){
            int x1 = Integer.parseInt(txtField1.getText());
            int x2 = Integer.parseInt(txtField2.getText());
            int suma = x1 + x2;
            lblResultado.setText(String.valueOf(suma));
        }
        
        
    }
}
