package login;

public class Login {
    public static boolean autenticar(String usuario, String clave){
        if (usuario.equals("SofiaDiaz") && clave.equals("Sofi789")){
            return true;
        }
        return false;
    }
    
}
