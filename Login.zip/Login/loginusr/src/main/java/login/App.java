package login;
import javax.swing.*;
import java.awt.event.*;

public class App extends JFrame implements ActionListener 
{
    private JLabel lblUsuario;
    private JLabel lblClave;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton btnLogin;
    
    public App(){
        setLayout(null);
        lblUsuario = new JLabel("Usuario");
        lblUsuario.setBounds(20,20,100,30);
        lblClave = new JLabel("Clave");
        lblClave.setBounds(20,50,100,30);
        add(lblClave);
        add(lblUsuario);
        textField = new JTextField();
        textField.setBounds(120, 20, 100,20);
        passwordField = new JPasswordField();
        passwordField.setBounds(120,50,100,20); 
        add(textField);
        add(passwordField);
        btnLogin = new JButton("Login");
        btnLogin.setBounds(20, 90,  100,20);
        btnLogin.addActionListener(this);
        add(btnLogin);
    }
    public static void main( String[] args )
    {
        App login = new App();
        login.setBounds(20,20,280,170);
        login.setVisible(true);
        login.setTitle("Login");
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == btnLogin){
        String clave = new String(passwordField.getPassword());
        if (Login.autenticar(textField.getText(), clave)){
            JOptionPane.showMessageDialog(App.this, "Ingreso exitoso", "Login", JOptionPane.INFORMATION_MESSAGE); //ventana emergente de mensaje
        }else{
            JOptionPane.showMessageDialog(App.this, "Usuario o clave incorrecta", "Login", JOptionPane.ERROR_MESSAGE);
        }
       }

        
    }
}
