package book;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBManager implements AutoCloseable{
    private Connection connection;

    public DBManager() throws SQLException{
        connect();
    }

    private void connect() throws SQLException{
        String url = "jdbc:sqlite:C:\\Users\\robot\\Documents\\baseDatos\\BookShop.db";
        connection = DriverManager.getConnection(url);
    }

    public List<Book> listBooks() throws SQLException{
        List<Book> libros = new ArrayList<Book>();
        String sql = "SELECT * FROM Libro";
        try(
            Statement stm  = connection.createStatement();
            ResultSet rs = stm.executeQuery(sql);
        )
        {      
            while (rs.next()){
                Book libro = new Book();
                libro.setId(rs.getInt("id_libro"));
                libro.setIsbn(rs.getString("isbn"));
                libro.setTitle(rs.getString("titulo"));
                libro.setYear(rs.getInt("anio"));
                libros.add(libro);
            }
        }
        return libros;
    }
    public Book searchBook(String isbn) throws SQLException{
        ResultSet rs = null;
        Statement stm = null;
        Book libro = null;
        try{
            stm = connection.createStatement();
            String sql = "select * from Libro where isbn = '" + isbn + "'";
            rs = stm.executeQuery(sql);
            while (rs.next()){
                libro = new Book();
                libro.setId(rs.getInt("id_libro"));
                libro.setIsbn(rs.getString("isbn"));
                libro.setTitle(rs.getString("titulo"));
                libro.setYear(rs.getInt("anio"));
            }
        }
        finally{
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
        }
        return libro;    
    }
    public int getStock(int bookId) throws SQLException{
        int cantidad = 0;
        String sql = "select cantidad from inventario where id_libro = ?";
        try(
            PreparedStatement stm = connection.prepareStatement(sql);
        ){
            stm.setInt(1, bookId);
            try(
                ResultSet rs = stm.executeQuery();
            ){
                if (rs.next()){
                    cantidad = rs.getInt("cantidad");
                }
            }
        }
        return cantidad;
    }

    public boolean sellBook(Book book, int units) throws SQLException{
        Integer cantidad = 0;
        String sql = "select cantidad from inventario where id_libro = ?";
        try(
            PreparedStatement stm = connection.prepareStatement(sql);    
        ){
            stm.setInt(1, book.getId());
            try( 
                var rs = stm.executeQuery();
            ){
                rs.next();
                cantidad = rs.getInt("cantidad");
            }
            if (cantidad >= units){
                String sql2 = "insert into Ventas (fecha_venta, id_libro, cantidad) values(?,?,?)";
                var stm2 = connection.prepareStatement(sql2);
                stm2.setString(1, LocalDateTime.now().toString());
                stm2.setInt(2, book.getId());
                stm2.setInt(3,units);
                stm2.executeUpdate();
                String sql3 = "update Inventario set cantidad = ? where id_libro = ?";
                stm2 = connection.prepareStatement(sql3);
                stm2.setInt(1, cantidad - units);
                stm2.setInt(2, book.getId());
                stm2.executeUpdate();
                stm2.close();
            }else{
                return false;
            }
        }
        return true;
    }

    @Override
    public void close() throws Exception {
        if(connection !=null){
            connection.close();
        }
        connection = null;
    
        
    }

}

