
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;

public class App extends JFrame {

    public App(){
        String[] nombreColumnas = {"Nombre", "Edad", "Extranjero"};
        Object[][] datos = {
            {"Ana",25, false},
            {"Jean",28, true},
            {"Pedro",30, false}
        };

        DefaultTableModel modelo = new DefaultTableModel(datos,nombreColumnas);
        JTable tabla = new JTable(modelo);

        //Agregar columna nueva
        String[] datosColumnaNueva = {"Contadora","Ingeniero","Administrador"};
        modelo.addColumn("Profesional",datosColumnaNueva);

        //Agregar filaNueva
        Object[] filaNueva = {"Antonio",40, false, "Médico"};
        modelo.addRow(filaNueva);
        modelo.addRow(filaNueva);
        modelo.addRow(filaNueva);
        modelo.addRow(filaNueva);
        modelo.addRow(filaNueva);
        modelo.addRow(filaNueva);


        tabla.setPreferredScrollableViewportSize(new Dimension(250,100));
        add(tabla);
        JScrollPane scrollPane = new JScrollPane(tabla); 
        add(scrollPane);


    }


    public static void main(String[] args) throws Exception {
        App ventana = new App();    
        ventana.pack();
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
