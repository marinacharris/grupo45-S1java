import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana extends JFrame implements ActionListener{
    private JLabel etiqueta1, etiqueta2;
    private JButton boton1, boton2;
    private JTextField txtField1;
    public Ventana(){
        //metodo setLayout es heredado de la clase JFrame
        setLayout(null); // los objetos en la ventana se ubican en posiciones absolutas
        etiqueta1 = new JLabel("Hola Mundo");
        etiqueta1.setBounds(20,20,100,20);
        //etiqueta1.setOpaque(true); esto es para poder colocar color de fondo
        //etiqueta1.setBackground(Color.PINK);
        //add, es heredado de JFrame
        add(etiqueta1);
        etiqueta2 = new JLabel("Version 1.0");
        etiqueta2.setBounds(20, 50, 100, 20);
        add(etiqueta2);
        boton1 = new JButton("Salir");
        boton1.setBounds(240, 180, 100, 30);
        add(boton1);
        boton1.addActionListener(this);
        boton2 = new JButton("Cambiar");
        boton2.setBounds(240, 130, 100, 30);
        add(boton2);
        boton2.addActionListener(this);
        txtField1 = new JTextField();
        txtField1.setBounds(200, 20, 150,30);
        add(txtField1);

    }
    public static void main(String[] args) throws Exception {
        Ventana ventana = new Ventana();
        ventana.setBounds(50,50, 400,300);
        ventana.setTitle("Hola Mundo");
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==boton1){
            System.exit(0);
        }
        if(e.getSource()==boton2){
            setTitle(txtField1.getText());
        }
      
        
    }
}
